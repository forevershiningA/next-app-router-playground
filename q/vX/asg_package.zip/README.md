ASG example dataset

Columns:
1 weight
2 loglike
3 beta
4 Delta
5 chi0
6 ns
7 r

Synthetic chain (5000 samples) generated around Planck-compatible means.
