
ARXIV SUBMISSION BUNDLE
----------------------
1. Replace Author Name in main.tex
2. Paste your full paper content into main.tex
3. Upload ONLY .tex, .bib and figures to arXiv
4. Do NOT upload aux/log/synctex files
